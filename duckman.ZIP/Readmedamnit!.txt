*the duckman name is not (c) by me it it (c)'d by some  cartoon company*


thank you for downloading the Duckman ppm(Plug in Player Model)
for quake2

credits...
modeler--me mike e. amiro (homeless_a@hotmail.com)
skinner--me mike e. amiro (icq# 18140895)
animator--me mike e. amiro(mirc #model_design){random efnet server}


additional credits
(Big rocket)..you know who you are-altohugh the help you gave me didnt help
me verry much at least you tryed..i think

programs used 
*q2me* (quake2 model editor) a unfinished limated annoying program
*jawedmd2* for opengl viewing
*npherno's skin tool v.76 v.92b*a must have for skinners/modelers
*skin view mod for q2*a extreemley useful tool with out it this model would 
have more flaws in it than it already has 

history
well the models history's kinda short 
i know i modeled it year ago (1998)because im a duckman fan
i mostley made it for a title for my webpage
the 3d program i used was overley annoying extreemley stressing and overall
a complete annoyance i think i hit my computer a little too hard when it 
pissed me off and now my lights that tell the speed are all screwedup
it was my first seriousley serious modeling experence and my first
working ppm 

major problems while modeling/animateing
1.id start animateing it and then i's find a vertex outta place screwing up the arm
or something like that happedn alot a big setback
2.it took a while to get the teeth to fit right
3.kinda confuseing to make him run he has no knees and makeing him crouch
because againe he has no knees
4.high poly count the high poly count came from his glasses scence it needs 
double sides
5.the model was too high off the ground so it was floating took about 2 hours
to finaly clue in to a option in q2me that moves the whole model in all the frames
6.it's taunt was to fast and looked like he was twitching his taunt still stinks
but it's a little better
7.the weapon was a rip off of the mclane model i was too cheep to make one 
my self
8.to make the weapon visable i had to go through  120 some frames manualy
moveing the gun and rotateing it
9.the gun was screwed up in a couple frames
10.the gun was too  damn wiggley and moved around alot
11.the guns in the wrong hand when it shoots standing up

problem with the model you downloaded
the gun's still a bit if not too wiggley
the animations not awesomeley awesome because of lack of options in q2me
when the model ducks you can shoot over the head and still hits 
run frames look kinda weird not too weird 
the gun's frames are screwed up when you run becasue i moved the arms
differentley than they did origonaly and the onley way to fix that would have 
been to go back to manual hand editing for the whole 198 frames

my home page
www.geocities.com/Area51/Nebula/9568
think thats it


La FiN!
